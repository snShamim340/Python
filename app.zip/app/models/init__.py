# app/models/__init__.py

from .user import User
from .server import Server
from .session import Session

# Export all models for easy access
__all__ = ['User', 'Server', 'Session']

# Convenience imports for database operations
from app import db

def init_models():
    """Initialize database models (called during app startup)"""
    # This ensures all models are registered with SQLAlchemy
    passpass